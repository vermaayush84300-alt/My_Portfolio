# Ayush Kumar — Frontend & React Developer Portfolio

A modern, high-performance, interactive personal portfolio web application built with **React 18 + Vite**, a graphite geometric background, switchable color themes, interactive skill search & filtering, project highlights, verified certificate lightbox modal, and responsive mobile-first design.

---

## 🌟 Features

- **🎨 Graphite Background + 5 Professional Color Themes (live switcher)**:
  - 🏆 **Executive Gold** (default): champagne gold on graphite black with silver highlights.
  - 💼 **Corporate Sapphire**: trustworthy blue, ideal for IT services and product companies.
  - 📈 **Capital Emerald**: confident green for finance, consulting and analytics roles.
  - 🎓 **Campus Ruby**: warm crimson that stands out in college and placement portals.
  - ⚪ **Pure Titanium**: minimal monochrome silver.
- **⚡ Dynamic Hero**:
  - Live animated role rotator (*Frontend Developer*, *React.js Specialist*, *UI/UX Rebuilder*, *Web Application Engineer*, *C++ & DSA Enthusiast*).
  - Live pulse status badge for availability.
  - Floating tech chips and quick metrics.
- **🛠️ Interactive Skills Matrix**:
  - Live search bar and category tabs (*Languages*, *Frontend*, *Tools*, *Concepts*).
  - Proficiency level indicators (*Expert*, *Advanced*, *Proficient*, *Core*).
- **💼 Featured Projects Showcase**:
  - Category filter pills (*All*, *E-Commerce*, *Ed-Tech*, *AgriTech*).
  - Live deployment links and GitHub repository shortcuts.
- **📜 Verified Certifications Lightbox**:
  - High-resolution modal viewer with ESC key & click-outside support.
- **📬 Contact Section**:
  - 1-click **Copy Email to Clipboard** with instant toast feedback.
  - Interactive validation form.
- **📈 Scroll Progress Bar & Floating Back-to-Top Button**.

---

## 🚀 Quick Start (Run Locally)

1. **Install dependencies**:
   ```bash
   npm install
   ```

2. **Start the local development server**:
   ```bash
   npm run dev
   ```

3. Open your browser and navigate to:
   ```
   http://localhost:5173
   ```

---

## 📦 Build for Production (Deploy to Netlify / Vercel / GitHub Pages)

```bash
npm run build
```
The optimized production bundle will be generated inside the `dist/` directory, ready to be deployed.

---

## 🛠️ Tech Stack

- **Framework**: React 18
- **Bundler**: Vite 5
- **Icons**: Lucide React
- **Typography**: Google Fonts (*Space Grotesk*, *Plus Jakarta Sans*, *JetBrains Mono*)
- **Styling**: Modern Responsive CSS3 (CSS Variables, Flexbox, CSS Grid, Glassmorphism, Micro-Animations)
